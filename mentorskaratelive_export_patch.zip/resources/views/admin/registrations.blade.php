@include('admin.layout.header')
@include('admin.layout.navbar')
@include('admin.layout.sidebar')

@php
    use Illuminate\Support\Str;

    $classGroups = [
        'LKG-UKG' => ['LKG', 'UKG'],
        'I – II STD' => ['I STD', 'II STD'],
        'III – IV STD' => ['III STD', 'IV STD'],
        'V – VI STD' => ['V STD', 'VI STD'],
        'VII – VIII STD' => ['VII STD', 'VIII STD'],
        'IX - X STD' => ['IX STD', 'X STD'],
        'above' => ['above'],
    ];

    $weightRanges = [];
    $weightRanges['Below 25 kg'] = fn($w) => $w < 25;
    for ($start = 25; $start < 75; $start += 5) {
        $end = $start + 5;
        $label = "{$start}-{$end} kg";
        $weightRanges[$label] = fn($w) => $w >= $start && $w < $end;
    }
    $weightRanges['Above 75 kg'] = fn($w) => $w >= 75;

    $getField = function ($data, $keyword) {
        $item = collect($data ?? [])->first(function ($f) use ($keyword) {
            return isset($f['label']) && Str::contains(strtolower($f['label']), strtolower($keyword));
        });
        $val = $item['value'] ?? '';
        return is_array($val) ? implode(', ', $val) : $val;
    };

    $eventSearch = strtolower(request('event_search') ?? '');
    $studentSearch = strtolower(request('student_search') ?? '');
    $filterEventId = request('event_id');
@endphp

<style>
    .event-header {
        background: linear-gradient(135deg, #1b0202, #000000);
        color: #fff;
    }
    .badge-class {
        background-color: #6c757d;
        color: #fff;
        font-size: 0.75rem;
    }
    .btn-custom {
        background: #000;
        color: #fff;
        border: 1px solid #000;
    }
    .btn-custom:hover {
        background: #fff;
        color: #b30000;
        border-color: #b30000;
    }
</style>

<main class="page-content">
    <div class="container py-4">
        
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold">Event Registrations</h2>
            <div class="d-flex gap-2">
                <a href="{{ route('admin.registrations.create') }}" class="btn btn-success btn-sm">+ Create Registration</a>
            <a href="{{ route('admin.event') }}" class="btn btn-secondary btn-sm">← Back to Events</a>
            </div>
        </div>

        <!-- Filters -->
        <form method="GET" class="mb-4">
            <div class="row g-2">
                <div class="col-md-4">
                    <input type="text" name="event_search" value="{{ request('event_search') }}"
                           placeholder="Search by Event Title" class="form-control">
                </div>
                <div class="col-md-4">
                    <input type="text" name="student_search" value="{{ request('student_search') }}"
                           placeholder="Search by Student Name or Registration Code" class="form-control">
                </div>
                <div class="col-md-2">
                    <button class="btn w-100" style=" background: linear-gradient(135deg, #4a0000, #000000);color:white;">Search</button>
                </div>
            </div>
        </form>

        <!-- Events Loop -->
        @forelse($events as $event)
            @php
                if ($filterEventId && $event->id != $filterEventId) continue;
                if ($eventSearch && !str_contains(strtolower($event->title), $eventSearch)) continue;

                $registrations = $event->registrations->filter(function ($reg) use ($studentSearch) {
                    if (!$studentSearch) return true;
                    if (str_contains(strtolower($reg->registration_code), $studentSearch)) return true;
                    foreach ($reg->submitted_data ?? [] as $field) {
                        $value = is_array($field['value'] ?? null) ? implode(' ', $field['value']) : $field['value'] ?? '';
                        if (str_contains(strtolower($value), $studentSearch)) return true;
                    }
                    return false;
                });

                $isFiltering = $eventSearch || $studentSearch || $filterEventId;
                if ($isFiltering && $registrations->isEmpty()) continue;

                $catName = strtolower($event->category->name ?? '');
                $isCompetition = Str::contains($catName, 'competition');
                $isKyu = Str::contains($catName, 'kyu');
            @endphp

            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header event-header d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <div>
                        <h5 class="mb-1">{{ $event->title }}</h5>
                        <small>{{ \Carbon\Carbon::parse($event->event_date)->format('d-m-Y') }} | {{ $event->venue }}</small>
                        <div class="mt-2 d-flex flex-wrap align-items-center gap-2">
                            <span class="badge bg-primary" style="font-size: 0.85rem; padding: 6px 10px;">
                                <i class="bi bi-check-circle-fill"></i> {{ $event->paid_count ?? $registrations->count() }} paid registrations for this event
                            </span>
                            @if (($event->pending_count ?? 0) > 0)
                                <a href="{{ route('admin.pending', ['event_id' => $event->id]) }}" class="badge bg-warning text-dark text-decoration-none" style="font-size: 0.85rem; padding: 6px 10px;">
                                    <i class="bi bi-clock-history"></i> {{ $event->pending_count }} pending registrations
                                </a>
                            @endif
                        </div>
                    </div>
                    <div class="d-flex gap-2 align-items-center flex-wrap">
                        <a href="{{ route('admin.events.registrations', $event->id) }}" class="btn btn-sm btn-info text-white">
                            <i class="bi bi-eye"></i> View Event Responses
                        </a>
                        <a href="{{ route('admin.event.export', ['eventId' => $event->id]) }}" class="btn btn-custom btn-sm">Export Excel</a>
                        @if ($registrations->count())
                            <a href="{{ route('admin.event.pdf.all', ['eventId' => $event->id]) }}" target="_blank" class="btn btn-custom btn-sm">📄 Download All PDFs</a>
                        @endif
                    </div>
                </div>

                <div class="card-body">
                    @if ($registrations->isEmpty())
                        <p class="text-muted">No registrations found for this search.</p>
                    @else
                        {{-- CLASS GROUPS LOOP --}}
                        @foreach ($classGroups as $groupLabel => $classes)
                            @php
                                $groupRegs = $registrations->filter(function ($reg) use ($classes, $getField) {
                                    $classVal = $getField($reg->submitted_data, 'class');
                                    return $classVal && in_array($classVal, $classes, true);
                                });
                            @endphp

                            @if ($groupRegs->isNotEmpty())
                                <div class="mb-4">
                                    <h6 class="fw-bold border-bottom pb-1 text-secondary">{{ $groupLabel }}</h6>

                                    <!-- Competition -->
                                    @if ($isCompetition)
                                        @foreach ($weightRanges as $rangeLabel => $condition)
                                            @php
                                                $subRegs = $groupRegs->filter(function ($reg) use ($condition, $getField) {
                                                    $w = (float) $getField($reg->submitted_data, 'weight');
                                                    return $condition($w);
                                                });
                                            @endphp

                                            @if ($subRegs->isNotEmpty())
                                                <div class="ps-3 mb-3">
                                                    <span class="badge bg-danger mb-2">{{ $rangeLabel }}</span>
                                                    <div class="table-responsive">
                                                        <table class="table table-bordered table-sm align-middle">
                                                            <thead class="table-light">
                                                                <tr>
                                                                    <th>Registration ID</th>
                                                                    <th>Student Name</th>
                                                                    <th>Class</th>
                                                                    <th>Weight (kg)</th>
                                                                    <th>Payment Status</th>
                                                                    <th>Amount</th>
                                                                    <th>Submitted At</th>
                                                                    <th>Actions</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                @foreach ($subRegs as $reg)
                                                                    <tr>
                                                                        <td>{{ $reg->registration_code }}</td>
                                                                        <td>{{ $getField($reg->submitted_data, 'name') }}</td>
                                                                        <td>{{ $getField($reg->submitted_data, 'class') }}</td>
                                                                        <td>{{ $getField($reg->submitted_data, 'weight') }}</td>
                                                                        <td><span class="badge bg-success">Paid</span></td>
                                                                        <td><strong>₹{{ number_format($reg->amount ?? 0, 2) }}</strong></td>
                                                                        <td>{{ $reg->created_at->format('d M Y h:i A') }}</td>
                                                                        <td>
                                                                            <a href="{{ route('admin.certificate.layout', $reg->id) }}" class="btn btn-sm btn-success" target="_blank">Certificate</a>
                                                                            <a href="{{ route('admin.registration.viewpdf', ['registrationId' => $reg->id]) }}" class="btn btn-sm btn-primary">View</a>
                                                                            <a href="{{ route('registration.download.pdf', $reg->id) }}" class="btn btn-sm btn-info">Download</a>
                                                                            <a href="{{ route('admin.registrations.edit', $reg->id) }}" class="btn btn-sm btn-warning">Edit</a>
                                                                        </td>
                                                                    </tr>
                                                                @endforeach
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            @endif
                                        @endforeach

                                    <!-- Kyu / Normal -->
                                    @else
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-sm align-middle">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>Registration ID</th>
                                                        <th>Student Name</th>
                                                        <th>Class</th>
                                                        <th>Payment Status</th>
                                                        <th>Amount</th>
                                                        <th>Submitted At</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach ($groupRegs as $reg)
                                                        <tr>
                                                            <td>{{ $reg->registration_code }}</td>
                                                            <td>{{ $getField($reg->submitted_data, 'name') }}</td>
                                                            <td>{{ $getField($reg->submitted_data, 'class') }}</td>
                                                            <td><span class="badge bg-success">Paid</span></td>
                                                            <td><strong>₹{{ number_format($reg->amount ?? 0, 2) }}</strong></td>
                                                            <td>{{ $reg->created_at->format('d M Y h:i A') }}</td>
                                                            <td>
                                                                <a href="{{ route('admin.certificate.layout', $reg->id) }}" class="btn btn-sm btn-success" target="_blank">Certificate</a>
                                                                <a href="{{ route('admin.registration.viewpdf', ['registrationId' => $reg->id]) }}" class="btn btn-sm btn-primary">View</a>
                                                                <a href="{{ route('registration.download.pdf', $reg->id) }}" class="btn btn-sm btn-info">Download</a>
                                                                <a href="{{ route('admin.registrations.edit', $reg->id) }}" class="btn btn-sm btn-warning">Edit</a>
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    @endif
                                </div>
                            @endif
                        @endforeach
                    @endif
                </div>
            </div>
        @empty
            <p class="text-muted">No events found.</p>
        @endforelse
    </div>
</main>

@include('admin.layout.footer')
