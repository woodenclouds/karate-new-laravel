<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Certificate of Diploma</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Times New Roman', Times, 'Times Roman', serif;
            color: #000;
            background: #fff;
        }

        .certificate-container {
            position: relative;
            background: #fff;
            overflow: hidden;
        }

        /* Belt Certificate Size: 24cm x 33cm */
        .certificate-belt {
            width: 24cm;
            height: 33cm;
        }

        /* Competition Certificate Size: 21cm x 29.7cm (A4) */
        .certificate-competition {
            width: 21cm;
            height: 29.7cm;
        }

        /* Background Image */
        .background-image {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 1;
            object-fit: cover;
        }

        /* Content Container - Overlay on template */
        .content {
            position: absolute;
            z-index: 10;
            width: 100%;
            height: 100%;
            padding: 0;
        }

        /* Dynamic Fields - Positioned absolutely to match template */
        .dynamic-field {
            position: absolute;
            font-family: 'Times New Roman', Times, 'Times Roman', serif;
            color: #000;
            font-weight: normal;
            white-space: nowrap;
            line-height: 1.2;
        }

        /* ============================================
           BELT CERTIFICATE POSITIONING
           ============================================ */
        .certificate-belt .field-name {
            top: 21.0cm;
            left: 5.5cm;
            font-size: 13pt;
            font-weight: normal;
            text-transform: uppercase;
            color: #c00;
            max-width: 13cm;
            overflow: hidden;
        }

        .certificate-belt .field-place {
            top: 22.3cm;
            left: 5.5cm;
            font-size: 13pt;
            font-weight: normal;
            text-transform: uppercase;
            color: #000;
            max-width: 13cm;
            overflow: hidden;
        }

        .certificate-belt .field-reg-no {
            top: 23.5cm;
            left: 5.5cm;
            font-size: 13pt;
            font-weight: normal;
            text-transform: uppercase;
            color: #000;
            max-width: 13cm;
            overflow: hidden;
        }

        .certificate-belt .field-date-reg {
            top: 23.5cm;
            left: 15.5cm;
            font-size: 13pt;
            font-weight: normal;
            color: #000;
            max-width: 13cm;
            overflow: hidden;
        }

        /* ============================================
           COMPETITION CERTIFICATE POSITIONING
           ============================================ */
        .certificate-competition .field-name {
            top: 16.9cm;
            left: 9.5cm;
            font-size: 13pt;
            font-weight: normal;
            text-transform: uppercase;
            color: #000;
            max-width: 13cm;
            overflow: hidden;
        }

        .certificate-competition .field-place {
            top: 20.6cm;
            left: 7.4cm;
            font-size: 13pt;
            font-weight: normal;
            text-transform: uppercase;
            color: #000;
            max-width: 13cm;
            overflow: hidden;
        }

        .certificate-competition .field-reg-no {
            display: none; /* Hide Reg No for competition certificates */
        }

        .certificate-competition .field-category {
            top: 19.5cm;
            left: 7.4cm;
            font-size: 13pt;
            font-weight: normal;
            text-transform: uppercase;
            color: #000;
            max-width: 13cm;
            overflow: hidden;
        }

        .certificate-competition .field-date-reg {
            top: 20.6cm;
            left: 3.9cm;
            font-size: 13pt;
            font-weight: normal;
            color: #000;
            max-width: 13cm;
            overflow: hidden;
        }
    </style>
</head>
<body>
@php
    $certificateType = strtolower($certificate->certificate_type ?? 'belt');
    $certificateClass = 'certificate-' . $certificateType;
@endphp
<div class="certificate-container {{ $certificateClass }}">
    <!-- Background Template Image -->
    @if($backgroundImage)
        <img src="{{ $backgroundImage }}" alt="Certificate Background" class="background-image">
    @endif

    <!-- Dynamic Content Overlay -->
    <div class="content">
        <!-- Name Field - NAME 名前 -->
        <div class="dynamic-field field-name">
            {{ isset($participant['name']) && !empty($participant['name']) ? strtoupper(trim($participant['name'])) : '' }}
        </div>

        <!-- Place Field - PLACE 場所 -->
        <div class="dynamic-field field-place">
            {{ isset($participant['place']) && !empty($participant['place']) ? strtoupper(trim($participant['place'])) : '' }}
        </div>

        <!-- Registration Number Field - REG. NO 登録番号 (Only for Belt certificates) -->
        @if($certificateType === 'belt')
            @php
                $regId = $participant['registration_id'] ?? '';
                $regNo = '';
                if (!empty(trim($regId))) {
                    $regNo = preg_replace('/^MENTORS/i', '', trim($regId));
                    $regNo = preg_replace('/\D/', '', $regNo);
                    if (strlen($regNo) > 4) $regNo = substr($regNo, -4);
                    $regNo = str_pad($regNo, 4, '0', STR_PAD_LEFT);
                }
            @endphp
            <div class="dynamic-field field-reg-no">
                {{ $regNo }}
            </div>
        @endif

        <!-- Category Field - CATEGORY (Only for Competition certificates) -->
        @if($certificateType === 'competition')
            <div class="dynamic-field field-category">
                {{ isset($participant['category']) && !empty($participant['category']) ? strtoupper(trim($participant['category'])) : '' }}
            </div>
        @endif

        <!-- Date of Registration Field - DATE OF REG. 登録日 -->
        <div class="dynamic-field field-date-reg">
            @if(isset($participant['date_of_reg']) && !empty($participant['date_of_reg']))
                @php
                    $dateStr = trim($participant['date_of_reg']);
                    try {
                        // Remove any Excel formatting
                        $dateStr = preg_replace('/\s+/', ' ', $dateStr);
                        
                        // Try YYYY-MM-DD format first
                        if (preg_match('/^\d{4}-\d{2}-\d{2}/', $dateStr)) {
                            $date = \Carbon\Carbon::createFromFormat('Y-m-d', substr($dateStr, 0, 10));
                            echo $date->format('d M Y');
                        }
                        // Try DD/MM/YYYY format
                        elseif (preg_match('/\d{1,2}\/\d{1,2}\/\d{4}/', $dateStr, $matches)) {
                            $date = \Carbon\Carbon::createFromFormat('d/m/Y', $matches[0]);
                            echo $date->format('d M Y');
                        }
                        // Try other formats
                        else {
                            $date = \Carbon\Carbon::parse($dateStr);
                            echo $date->format('d M Y');
                        }
                    } catch (\Exception $e) {
                        // If all parsing fails, display cleaned version
                        $cleanDate = preg_replace('/[^0-9\-\/ ]/', '', $dateStr);
                        echo $cleanDate ?: $dateStr;
                    }
                @endphp
            @elseif(isset($certificate->event_date) && !empty($certificate->event_date))
                {{ \Carbon\Carbon::parse($certificate->event_date)->format('d M Y') }}
            @endif
        </div>
    </div>
</div>
</body>
</html>
