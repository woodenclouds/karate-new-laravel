@include('admin.layout.header')
@include('admin.layout.navbar')
@include('admin.layout.sidebar')

@php
    use Illuminate\Support\Str;

    $classGroups = [
        'LKG-UKG' => ['LKG', 'UKG'],
        'I – II STD' => ['I STD', 'II STD'],
        'III – IV STD' => ['III STD', 'IV STD'],
        'V – VI STD' => ['V STD', 'VI STD'],
        'VII – VIII STD' => ['VII STD', 'VIII STD'],
        'IX - X STD' => ['IX STD', 'X STD'],
        'above' => ['above'],
    ];

    $weightRanges = [];
    $weightRanges['Below 25 kg'] = fn($w) => $w < 25;
    for ($start = 25; $start < 75; $start += 5) {
        $end = $start + 5;
        $label = "{$start}-{$end} kg";
        $weightRanges[$label] = fn($w) => $w >= $start && $w < $end;
    }
    $weightRanges['Above 75 kg'] = fn($w) => $w >= 75;

    $getField = function ($data, $keyword) {
        $item = collect($data ?? [])->first(function ($f) use ($keyword) {
            return isset($f['label']) && Str::contains(strtolower($f['label']), strtolower($keyword));
        });
        $val = $item['value'] ?? '';
        return is_array($val) ? implode(', ', $val) : $val;
    };

    $eventSearch = strtolower(request('event_search') ?? '');
    $studentSearch = strtolower(request('student_search') ?? '');
    $filterEventId = request('event_id');
@endphp

<style>
    .event-header {
        background: linear-gradient(135deg, #1b0202, #000000);
        color: #fff;
    }
    .badge-class {
        background-color: #6c757d;
        color: #fff;
        font-size: 0.75rem;
    }
    .btn-custom {
        background: #000;
        color: #fff;
        border: 1px solid #000;
    }
    .btn-custom:hover {
        background: #fff;
        color: #b30000;
        border-color: #b30000;
    }
</style>

<main class="page-content">
    <div class="container py-4">
        
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold">Event Registrations</h2>
            <div class="d-flex gap-2">
                <a href="{{ route('admin.registrations.create') }}" class="btn btn-success btn-sm">+ Create Registration</a>
            <a href="{{ route('admin.event') }}" class="btn btn-secondary btn-sm">← Back to Events</a>
            </div>
        </div>

        <!-- Filters & Event Selector -->
        <div class="card mb-4 border-0 shadow-sm">
            <div class="card-body p-3 bg-light rounded">
                <form method="GET" action="{{ route('admin.registrations') }}" id="filterForm">
                    <div class="row g-2 align-items-center">
                        <div class="col-lg-5 col-md-6">
                            <label class="form-label small fw-bold text-muted mb-1">Academy Event:</label>
                            <select name="event_id" class="form-select form-select-sm" onchange="document.getElementById('filterForm').submit();">
                                @if(isset($currentEvent) && $currentEvent)
                                    <option value="{{ $currentEvent->id }}" {{ ($selectedEventId == $currentEvent->id) ? 'selected' : '' }}>
                                        ★ Current Event: {{ $currentEvent->title }} ({{ \Carbon\Carbon::parse($currentEvent->event_date)->format('d M Y') }})
                                    </option>
                                @endif
                                <option value="all" {{ ($selectedEventId === 'all') ? 'selected' : '' }}>
                                    -- Show All Events --
                                </option>
                                @if(isset($allEvents))
                                    <optgroup label="Select Event (Previous / Other)">
                                        @foreach($allEvents as $ev)
                                            <option value="{{ $ev->id }}" {{ ($selectedEventId == $ev->id) ? 'selected' : '' }}>
                                                {{ $ev->title }} ({{ \Carbon\Carbon::parse($ev->event_date)->format('d M Y') }})
                                            </option>
                                        @endforeach
                                    </optgroup>
                                @endif
                            </select>
                        </div>
                        <div class="col-lg-2 col-md-3">
                            <label class="form-label small fw-bold text-muted mb-1">Sort Events:</label>
                            <select name="sort" class="form-select form-select-sm" onchange="document.getElementById('filterForm').submit();">
                                <option value="desc" {{ ($sort ?? 'desc') === 'desc' ? 'selected' : '' }}>Newest First</option>
                                <option value="asc" {{ ($sort ?? '') === 'asc' ? 'selected' : '' }}>Oldest First</option>
                            </select>
                        </div>
                        <div class="col-lg-3 col-md-5">
                            <label class="form-label small fw-bold text-muted mb-1">Search Participant:</label>
                            <input type="text" name="student_search" value="{{ request('student_search') }}"
                                   placeholder="Student Name or Reg Code" class="form-control form-control-sm">
                        </div>
                        <div class="col-lg-2 col-md-4 d-flex align-items-end gap-1" style="padding-top: 22px;">
                            <button type="submit" class="btn btn-sm btn-dark flex-grow-1">
                                <i class="bi bi-search"></i> Search
                            </button>
                            <a href="{{ route('admin.registrations') }}" class="btn btn-sm btn-outline-secondary" title="Reset to Current Event">
                                <i class="bi bi-arrow-counterclockwise"></i>
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Events Loop -->
        @forelse($events as $event)
            @php
                if ($filterEventId && $filterEventId !== 'all' && $event->id != $filterEventId) continue;
                if ($eventSearch && !str_contains(strtolower($event->title), $eventSearch)) continue;

                $registrations = $event->registrations->filter(function ($reg) use ($studentSearch) {
                    if (!$studentSearch) return true;
                    if (str_contains(strtolower($reg->registration_code), $studentSearch)) return true;
                    foreach ($reg->submitted_data ?? [] as $field) {
                        $val = $field['value'] ?? '';
                        $strVal = is_array($val) ? implode(' ', $val) : (string)$val;
                        if (str_contains(strtolower($strVal), $studentSearch)) return true;
                    }
                    return false;
                });

                $isFiltering = $eventSearch || $studentSearch || ($filterEventId && $filterEventId !== 'all');
                if ($isFiltering && $registrations->isEmpty()) continue;

                $catName = strtolower($event->category->name ?? '');
                $isCompetition = Str::contains($catName, 'competition');
                $isKyu = Str::contains($catName, 'kyu');
                $isCurrentEvent = isset($currentEvent) && $currentEvent && ($currentEvent->id == $event->id);
            @endphp

            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header event-header d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <div>
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <h5 class="mb-0">{{ $event->title }}</h5>
                            @if($isCurrentEvent)
                                <span class="badge bg-success"><i class="bi bi-star-fill"></i> Current Academy Event</span>
                            @endif
                        </div>
                        <small>{{ \Carbon\Carbon::parse($event->event_date)->format('d-m-Y') }} | {{ $event->venue }}</small>
                        <div class="mt-2 d-flex flex-wrap align-items-center gap-2">
                            <span class="badge bg-primary" style="font-size: 0.85rem; padding: 6px 10px;">
                                <i class="bi bi-check-circle-fill"></i> {{ $event->paid_count ?? $registrations->count() }} Paid
                            </span>
                            <span class="badge bg-success" style="font-size: 0.85rem; padding: 6px 10px;">
                                <i class="bi bi-person-check-fill"></i> {{ $event->attended_count ?? 0 }} Attended
                            </span>
                            @if (($event->pending_count ?? 0) > 0)
                                <a href="{{ route('admin.pending', ['event_id' => $event->id]) }}" class="badge bg-warning text-dark text-decoration-none" style="font-size: 0.85rem; padding: 6px 10px;">
                                    <i class="bi bi-clock-history"></i> {{ $event->pending_count }} Pending
                                </a>
                            @endif
                        </div>
                    </div>
                    <div class="d-flex gap-2 align-items-center flex-wrap">
                        <a href="{{ route('admin.events.registrations', $event->id) }}" class="btn btn-sm btn-info text-white" title="View, manage attendance, and responses">
                            <i class="bi bi-eye"></i> View Responses
                        </a>
                        <a href="{{ route('admin.event.certificates.download', ['eventId' => $event->id]) }}" class="btn btn-primary btn-sm" title="Download certificate PDFs for all attended participants">
                            <i class="bi bi-award-fill"></i> Download Certificates
                        </a>
                        <a href="{{ route('admin.event.export.attended', ['eventId' => $event->id]) }}" class="btn btn-outline-light btn-sm" title="Export attended participants to Excel">
                            <i class="bi bi-file-earmark-excel"></i> Export Attended (Excel)
                        </a>
                        <a href="{{ route('admin.event.export', ['eventId' => $event->id]) }}" class="btn btn-custom btn-sm" title="Export paid registrations">
                            <i class="bi bi-file-earmark-excel"></i> Export Paid
                        </a>
                        <a href="{{ route('admin.event.export.pending', ['eventId' => $event->id]) }}" class="btn btn-warning btn-sm text-dark fw-bold" title="Export pending belt registrations">
                            <i class="bi bi-file-earmark-arrow-down"></i> Export Pending
                        </a>
                        @if ($registrations->count())
                            <a href="{{ route('admin.event.pdf.all', ['eventId' => $event->id]) }}" target="_blank" class="btn btn-outline-light btn-sm">
                                <i class="bi bi-download"></i> PDFs
                            </a>
                        @endif
                    </div>
                </div>

                <div class="card-body">
                    @if ($registrations->isEmpty())
                        <p class="text-muted">No registrations found for this search.</p>
                    @else
                        {{-- CLASS GROUPS LOOP --}}
                        @foreach ($classGroups as $groupLabel => $classes)
                            @php
                                $groupRegs = $registrations->filter(function ($reg) use ($classes, $getField) {
                                    $classVal = $getField($reg->submitted_data, 'class');
                                    return $classVal && in_array($classVal, $classes, true);
                                });
                            @endphp

                            @if ($groupRegs->isNotEmpty())
                                <div class="mb-4">
                                    <h6 class="fw-bold border-bottom pb-1 text-secondary">{{ $groupLabel }}</h6>

                                    <!-- Competition -->
                                    @if ($isCompetition)
                                        @foreach ($weightRanges as $rangeLabel => $condition)
                                            @php
                                                $subRegs = $groupRegs->filter(function ($reg) use ($condition, $getField) {
                                                    $w = (float) $getField($reg->submitted_data, 'weight');
                                                    return $condition($w);
                                                });
                                            @endphp

                                            @if ($subRegs->isNotEmpty())
                                                <div class="ps-3 mb-3">
                                                    <span class="badge bg-danger mb-2">{{ $rangeLabel }}</span>
                                                    <div class="table-responsive">
                                                        <table class="table table-bordered table-sm align-middle">
                                                            <thead class="table-light">
                                                                <tr>
                                                                    <th>Registration ID</th>
                                                                    <th>Student Name</th>
                                                                    <th>Class</th>
                                                                    <th>Weight (kg)</th>
                                                                    <th>Payment Status</th>
                                                                    <th>Amount</th>
                                                                    <th>Submitted At</th>
                                                                    <th>Actions</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                @foreach ($subRegs as $reg)
                                                                    <tr>
                                                                        <td>{{ $reg->registration_code }}</td>
                                                                        <td>{{ $getField($reg->submitted_data, 'name') }}</td>
                                                                        <td>{{ $getField($reg->submitted_data, 'class') }}</td>
                                                                        <td>{{ $getField($reg->submitted_data, 'weight') }}</td>
                                                                        <td><span class="badge bg-success">Paid</span></td>
                                                                        <td><strong>₹{{ number_format($reg->amount ?? 0, 2) }}</strong></td>
                                                                        <td>{{ $reg->created_at->format('d M Y h:i A') }}</td>
                                                                        <td>
                                                                            <a href="{{ route('admin.certificate.layout', $reg->id) }}" class="btn btn-sm btn-success" target="_blank">Certificate</a>
                                                                            <a href="{{ route('admin.registration.viewpdf', ['registrationId' => $reg->id]) }}" class="btn btn-sm btn-primary">View</a>
                                                                            <a href="{{ route('registration.download.pdf', $reg->id) }}" class="btn btn-sm btn-info">Download</a>
                                                                            <a href="{{ route('admin.registrations.edit', $reg->id) }}" class="btn btn-sm btn-warning">Edit</a>
                                                                        </td>
                                                                    </tr>
                                                                @endforeach
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            @endif
                                        @endforeach

                                    <!-- Kyu / Normal -->
                                    @else
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-sm align-middle">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>Registration ID</th>
                                                        <th>Student Name</th>
                                                        <th>Class</th>
                                                        <th>Payment Status</th>
                                                        <th>Amount</th>
                                                        <th>Submitted At</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach ($groupRegs as $reg)
                                                        <tr>
                                                            <td>{{ $reg->registration_code }}</td>
                                                            <td>{{ $getField($reg->submitted_data, 'name') }}</td>
                                                            <td>{{ $getField($reg->submitted_data, 'class') }}</td>
                                                            <td><span class="badge bg-success">Paid</span></td>
                                                            <td><strong>₹{{ number_format($reg->amount ?? 0, 2) }}</strong></td>
                                                            <td>{{ $reg->created_at->format('d M Y h:i A') }}</td>
                                                            <td>
                                                                <a href="{{ route('admin.certificate.layout', $reg->id) }}" class="btn btn-sm btn-success" target="_blank">Certificate</a>
                                                                <a href="{{ route('admin.registration.viewpdf', ['registrationId' => $reg->id]) }}" class="btn btn-sm btn-primary">View</a>
                                                                <a href="{{ route('registration.download.pdf', $reg->id) }}" class="btn btn-sm btn-info">Download</a>
                                                                <a href="{{ route('admin.registrations.edit', $reg->id) }}" class="btn btn-sm btn-warning">Edit</a>
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    @endif
                                </div>
                            @endif
                        @endforeach
                    @endif
                </div>
            </div>
        @empty
            <p class="text-muted">No events found.</p>
        @endforelse
    </div>
</main>

@include('admin.layout.footer')
